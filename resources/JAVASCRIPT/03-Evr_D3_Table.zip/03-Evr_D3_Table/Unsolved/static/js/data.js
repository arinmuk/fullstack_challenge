var data = [
  {
    weekday: "SUN",
    date: "July 1",
    high: 76,
    low: 63
  }, {
    weekday: "MON",
    date: "July 2",
    high: 77,
    low: 63
  }, {
    weekday: "TUE",
    date: "July 3",
    high: 77,
    low: 63
  }, {
    weekday: "WED",
    date: "July 4",
    high: 81,
    low: 65
  }, {
    weekday: "THU",
    date: "July 5",
    high: 87,
    low: 68
  }, {
    weekday: "FRI",
    date: "July 6",
    high: 91,
    low: 71
  }, {
    weekday: "SAT",
    date: "July 7",
    high: 91,
    low: 72
  }
];
