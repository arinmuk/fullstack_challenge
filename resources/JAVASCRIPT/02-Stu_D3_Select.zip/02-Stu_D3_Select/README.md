# D3 Select

In this activity, you will use D3 to add a new row of data to a table.

## Instructions

* Use D3 to convert the Bootstrap table into a striped table.

* Use D3 to select the table body and append a new row and cells for the new student name and grade.

## Hints

* [Bootstrap Striped Tables](http://getbootstrap.com/docs/3.3/css/#tables-striped)
