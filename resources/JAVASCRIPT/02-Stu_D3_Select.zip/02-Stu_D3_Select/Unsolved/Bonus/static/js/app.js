// Use D3 to select the table body

// Use D3 to select the table

// Use D3 to set the table class to `table table-striped`

// BONUS: Dynamic table
// Loop through an array of grades and build the entire table body from scratch
var grades = [["Malcolm", 80], ["Zoe", 85], ["Kaylee", 99], ["Simon", 99], ["Wash", 79]];
