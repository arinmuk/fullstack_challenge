# Olympic Trends

In this activity, you will analyze trends in olympic gold medal performances over the years to see if there are any relationship between time and performance.

## Instructions

* Create a scatter plot to plot the `high_jump`, `discus_throw`, and `long_jump` vs the `year`.

* Use three separate traces for this data.

## Bonus

* Customize the marker colors and symbol for each trace.
