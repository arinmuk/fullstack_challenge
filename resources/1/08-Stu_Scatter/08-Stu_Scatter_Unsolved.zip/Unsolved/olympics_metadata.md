# Olympic Trends

* Description: Gold Medal performance in several Track and Field events. The gold medal performance in the men's long jump, shot put, and high jump (measured in inches) for the modern Olympic series starting in 1900.

* The Olympics in 1896 are included for reference but made missing for standard analyses.

  * Number of cases: 20
  * Variable Names:
  * high_jump: Height of the high jump (inches)
  * Discus_Throw: Distance of the throw (inches)
  * long_jump: Distance of the jump (inches)
  * year: Year of the Olympics
