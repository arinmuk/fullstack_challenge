// Array of names
const names = ["Jane", "John", "Jimbo", "Jedediah"];
